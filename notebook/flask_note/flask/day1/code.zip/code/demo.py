# coding:utf-8


print(__name__)