# coding:utf-8

# from main import app


# @app.route("/register")
def register():
    return "register page"