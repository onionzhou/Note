# coding:utf-8

# from main import app


# @app.route("/get_order")  # app.route("/get_order")(get_order)
def get_order():
    return "get order page"



